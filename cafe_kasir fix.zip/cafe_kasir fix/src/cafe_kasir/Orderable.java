package cafe_kasir;


public interface Orderable {
    double calculateTotalPayment();

    void resetOrder();
}